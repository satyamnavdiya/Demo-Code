# Click to send

A Pen created on CodePen.io. Original URL: [https://codepen.io/dilums/pen/rNjpxjb](https://codepen.io/dilums/pen/rNjpxjb).

Based on [Send Button UI Interaction/Animation](https://dribbble.com/shots/12072574-Send-Button-UI-Interaction-Animation) by [Saransh Agarwal](https://dribbble.com/sar123)
